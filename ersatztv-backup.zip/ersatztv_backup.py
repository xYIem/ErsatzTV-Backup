#!/usr/bin/env python3
"""
ErsatzTV Backup Manager
System tray app for backing up and restoring ErsatzTV settings via GitHub.

Features:
- Import/Export settings to GitHub
- Auto-export on schedule
- Auto-backup on startup + launch ErsatzTV
- Run on Windows startup
- Auto-finds and updates logos path in database
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import os
import sys
import json
import subprocess
import threading
import shutil
import sqlite3
from pathlib import Path
from datetime import datetime
import winreg

# Try to import pystray for system tray (will need to be installed)
try:
    import pystray
    from PIL import Image, ImageDraw
    HAS_TRAY = True
except ImportError:
    HAS_TRAY = False

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

APP_NAME = "ErsatzTV Backup Manager"
VERSION = "1.0.0"
CONFIG_FILE = Path(os.environ.get('LOCALAPPDATA', '')) / "ErsatzTV-Backup" / "config.json"

DEFAULT_CONFIG = {
    'ersatztv_exe_path': '',
    'ersatztv_data_path': '',
    'logos_path': '',  # Will be auto-detected from database
    'import_repo_url': '',
    'export_repo_url': '',
    'auto_export_enabled': False,
    'auto_export_hours': 24,
    'auto_backup_on_startup': False,
    'run_on_startup': False,
}

# Files/folders to backup from ErsatzTV data directory
BACKUP_ITEMS = [
    'ersatztv.sqlite3',
    'scripts',
    'templates',
    'plex-secrets.json',
    'jellyfin-secrets.json',
    'emby-secrets.json',
]

# ═══════════════════════════════════════════════════════════════════════════════
# DATABASE HELPER FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def get_logos_path_from_db(db_path):
    """Read the channel logos path from ErsatzTV database"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Try different possible table/column names
        # ErsatzTV stores local media sources including artwork folders
        queries = [
            "SELECT Path FROM LocalMediaSource WHERE MediaType = 'Artwork' LIMIT 1",
            "SELECT Value FROM ConfigElement WHERE Key = 'artwork_folder'",
            "SELECT Path FROM MediaSource WHERE Name LIKE '%logo%' OR Name LIKE '%artwork%' LIMIT 1",
        ]
        
        for query in queries:
            try:
                cursor.execute(query)
                result = cursor.fetchone()
                if result and result[0]:
                    conn.close()
                    return result[0]
            except sqlite3.OperationalError:
                continue
        
        conn.close()
    except Exception as e:
        print(f"Error reading database: {e}")
    
    return None

def update_logos_path_in_db(db_path, old_path, new_path):
    """Update logos/artwork paths in ErsatzTV database for new machine"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Get all tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        
        updated = 0
        for table in tables:
            table_name = table[0]
            
            # Get columns for this table
            cursor.execute(f"PRAGMA table_info({table_name})")
            columns = cursor.fetchall()
            
            for col in columns:
                col_name = col[1]
                col_type = col[2]
                
                # Only update text/varchar columns that might contain paths
                if 'TEXT' in col_type.upper() or 'VARCHAR' in col_type.upper() or col_type == '':
                    try:
                        # Update any occurrence of the old path
                        cursor.execute(f"""
                            UPDATE {table_name} 
                            SET {col_name} = REPLACE({col_name}, ?, ?)
                            WHERE {col_name} LIKE ?
                        """, (old_path, new_path, f"%{old_path}%"))
                        updated += cursor.rowcount
                    except:
                        pass
        
        conn.commit()
        conn.close()
        return updated
    except Exception as e:
        print(f"Error updating database: {e}")
        return 0

def get_all_paths_from_db(db_path):
    """Get all file paths stored in the database for review"""
    paths = []
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check LocalMediaSource table (common in ErsatzTV)
        try:
            cursor.execute("SELECT Id, Name, Path FROM LocalMediaSource")
            for row in cursor.fetchall():
                paths.append({'table': 'LocalMediaSource', 'id': row[0], 'name': row[1], 'path': row[2]})
        except:
            pass
        
        # Check Library paths
        try:
            cursor.execute("SELECT Id, Name, Path FROM Library")
            for row in cursor.fetchall():
                paths.append({'table': 'Library', 'id': row[0], 'name': row[1], 'path': row[2]})
        except:
            pass
        
        # Check MediaSource
        try:
            cursor.execute("SELECT Id, Name, Path FROM MediaSource")
            for row in cursor.fetchall():
                paths.append({'table': 'MediaSource', 'id': row[0], 'name': row[1], 'path': row[2]})
        except:
            pass
            
        conn.close()
    except Exception as e:
        print(f"Error reading paths: {e}")
    
    return paths

# ═══════════════════════════════════════════════════════════════════════════════
# HELPER FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def load_config():
    """Load configuration from file"""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r') as f:
                saved = json.load(f)
                # Merge with defaults for any new keys
                config = DEFAULT_CONFIG.copy()
                config.update(saved)
                return config
        except:
            pass
    return DEFAULT_CONFIG.copy()

def save_config(config):
    """Save configuration to file"""
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)

def find_ersatztv_data():
    """Try to find ErsatzTV data directory"""
    paths = [
        Path(os.environ.get('LOCALAPPDATA', '')) / 'ersatztv',
        Path(os.environ.get('APPDATA', '')) / 'ersatztv',
        Path('C:/ProgramData/ersatztv'),
        Path('C:/ersatztv'),
    ]
    for p in paths:
        if p.exists() and (p / 'ersatztv.sqlite3').exists():
            return str(p)
    return ''

def find_ersatztv_exe():
    """Try to find ErsatzTV executable"""
    # Check common locations
    paths = [
        Path(os.environ.get('LOCALAPPDATA', '')) / 'ErsatzTV' / 'ErsatzTV.exe',
        Path(os.environ.get('PROGRAMFILES', '')) / 'ErsatzTV' / 'ErsatzTV.exe',
        Path('C:/ErsatzTV/ErsatzTV.exe'),
    ]
    for p in paths:
        if p.exists():
            return str(p)
    
    # Check if running and get path
    try:
        result = subprocess.run(
            ['powershell', '-Command', 
             'Get-Process -Name "ErsatzTV*" -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Path'],
            capture_output=True, text=True, timeout=5
        )
        if result.stdout.strip():
            return result.stdout.strip().split('\n')[0]
    except:
        pass
    
    return ''

def is_ersatztv_running():
    """Check if ErsatzTV is currently running"""
    try:
        result = subprocess.run(
            ['powershell', '-Command', 'Get-Process -Name "ErsatzTV*" -ErrorAction SilentlyContinue'],
            capture_output=True, text=True, timeout=5
        )
        return bool(result.stdout.strip())
    except:
        return False

def set_run_on_startup(enable):
    """Add/remove from Windows startup registry"""
    key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE)
        if enable:
            # Get the exe path
            if getattr(sys, 'frozen', False):
                exe_path = sys.executable
            else:
                exe_path = f'pythonw "{__file__}"'
            winreg.SetValueEx(key, APP_NAME, 0, winreg.REG_SZ, exe_path)
        else:
            try:
                winreg.DeleteValue(key, APP_NAME)
            except FileNotFoundError:
                pass
        winreg.CloseKey(key)
        return True
    except Exception as e:
        print(f"Failed to set startup: {e}")
        return False

def run_git_command(args, cwd=None):
    """Run a git command and return success, output"""
    try:
        result = subprocess.run(
            ['git'] + args,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=120
        )
        return result.returncode == 0, result.stdout + result.stderr
    except FileNotFoundError:
        return False, "Git is not installed. Please install Git from https://git-scm.com/"
    except Exception as e:
        return False, str(e)

# ═══════════════════════════════════════════════════════════════════════════════
# MAIN APPLICATION
# ═══════════════════════════════════════════════════════════════════════════════

class ErsatzTVBackupApp:
    def __init__(self, root):
        self.root = root
        self.root.title(f"{APP_NAME} v{VERSION}")
        self.root.geometry("550x650")
        self.root.resizable(True, True)
        self.root.minsize(500, 600)
        
        # Load config
        self.config = load_config()
        
        # Auto-find paths if not set
        if not self.config['ersatztv_data_path']:
            self.config['ersatztv_data_path'] = find_ersatztv_data()
        if not self.config['ersatztv_exe_path']:
            self.config['ersatztv_exe_path'] = find_ersatztv_exe()
        
        # Variables
        self.ersatztv_exe_var = tk.StringVar(value=self.config['ersatztv_exe_path'])
        self.ersatztv_data_var = tk.StringVar(value=self.config['ersatztv_data_path'])
        self.logos_path_var = tk.StringVar(value=self.config['logos_path'])
        self.import_repo_var = tk.StringVar(value=self.config['import_repo_url'])
        self.export_repo_var = tk.StringVar(value=self.config['export_repo_url'])
        self.auto_export_enabled_var = tk.BooleanVar(value=self.config['auto_export_enabled'])
        self.auto_export_hours_var = tk.StringVar(value=str(self.config['auto_export_hours']))
        self.auto_backup_startup_var = tk.BooleanVar(value=self.config['auto_backup_on_startup'])
        self.run_on_startup_var = tk.BooleanVar(value=self.config['run_on_startup'])
        
        # Build UI
        self.build_ui()
        
        # Auto-export timer
        self.auto_export_timer = None
        if self.config['auto_export_enabled']:
            self.start_auto_export_timer()
        
        # Handle window close
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
    
    def build_ui(self):
        """Build the main UI"""
        # Main container with padding
        container = ttk.Frame(self.root, padding="15")
        container.pack(fill=tk.BOTH, expand=True)
        
        # Title
        ttk.Label(container, text="ErsatzTV Backup Manager", 
                  font=('Segoe UI', 16, 'bold')).pack(anchor='w')
        ttk.Label(container, text="Backup and restore your ErsatzTV settings via GitHub",
                  foreground='gray').pack(anchor='w', pady=(0, 15))
        
        # === Paths Section ===
        paths_frame = ttk.LabelFrame(container, text="Paths", padding="10")
        paths_frame.pack(fill=tk.X, pady=5)
        
        # ErsatzTV Exe
        ttk.Label(paths_frame, text="ErsatzTV.exe:").pack(anchor='w')
        exe_row = ttk.Frame(paths_frame)
        exe_row.pack(fill=tk.X, pady=(0, 5))
        ttk.Entry(exe_row, textvariable=self.ersatztv_exe_var, width=50).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(exe_row, text="Browse", command=self.browse_exe).pack(side=tk.LEFT, padx=(5, 0))
        
        # ErsatzTV Data
        ttk.Label(paths_frame, text="ErsatzTV Data Folder:").pack(anchor='w')
        data_row = ttk.Frame(paths_frame)
        data_row.pack(fill=tk.X, pady=(0, 5))
        ttk.Entry(data_row, textvariable=self.ersatztv_data_var, width=50).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(data_row, text="Browse", command=self.browse_data).pack(side=tk.LEFT, padx=(5, 0))
        ttk.Button(data_row, text="Auto-Find", command=self.auto_find_data).pack(side=tk.LEFT, padx=(5, 0))
        
        # Logos Path
        ttk.Label(paths_frame, text="Channel Logos Folder (optional):").pack(anchor='w')
        logos_row = ttk.Frame(paths_frame)
        logos_row.pack(fill=tk.X)
        ttk.Entry(logos_row, textvariable=self.logos_path_var, width=50).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(logos_row, text="Browse", command=self.browse_logos).pack(side=tk.LEFT, padx=(5, 0))
        
        # === GitHub Repos Section ===
        repos_frame = ttk.LabelFrame(container, text="GitHub Repositories", padding="10")
        repos_frame.pack(fill=tk.X, pady=5)
        
        # Import Repo
        ttk.Label(repos_frame, text="Import from (GitHub URL):").pack(anchor='w')
        ttk.Entry(repos_frame, textvariable=self.import_repo_var, width=60).pack(fill=tk.X, pady=(0, 5))
        
        # Export Repo
        ttk.Label(repos_frame, text="Export to (GitHub URL):").pack(anchor='w')
        ttk.Entry(repos_frame, textvariable=self.export_repo_var, width=60).pack(fill=tk.X)
        
        ttk.Label(repos_frame, text="Example: https://github.com/username/ersatztv-backup.git",
                  foreground='gray', font=('Segoe UI', 8)).pack(anchor='w')
        
        # === Actions Section ===
        actions_frame = ttk.LabelFrame(container, text="Actions", padding="10")
        actions_frame.pack(fill=tk.X, pady=5)
        
        btn_row = ttk.Frame(actions_frame)
        btn_row.pack(fill=tk.X)
        
        ttk.Button(btn_row, text="Import Settings", command=self.do_import, width=18).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_row, text="Export Settings", command=self.do_export, width=18).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_row, text="Launch ErsatzTV", command=self.launch_ersatztv, width=18).pack(side=tk.LEFT, padx=5)
        
        # === Auto Export Section ===
        auto_frame = ttk.LabelFrame(container, text="Automation", padding="10")
        auto_frame.pack(fill=tk.X, pady=5)
        
        # Auto export row
        auto_row = ttk.Frame(auto_frame)
        auto_row.pack(fill=tk.X, pady=2)
        ttk.Checkbutton(auto_row, text="Auto-export every", 
                        variable=self.auto_export_enabled_var,
                        command=self.on_auto_export_toggle).pack(side=tk.LEFT)
        ttk.Entry(auto_row, textvariable=self.auto_export_hours_var, width=5).pack(side=tk.LEFT, padx=5)
        ttk.Label(auto_row, text="hours").pack(side=tk.LEFT)
        
        # Auto backup on startup
        ttk.Checkbutton(auto_frame, text="Auto-backup on startup, then launch ErsatzTV",
                        variable=self.auto_backup_startup_var).pack(anchor='w', pady=2)
        
        # Run on Windows startup
        ttk.Checkbutton(auto_frame, text="Run on Windows startup",
                        variable=self.run_on_startup_var,
                        command=self.on_startup_toggle).pack(anchor='w', pady=2)
        
        # === Log Section ===
        log_frame = ttk.LabelFrame(container, text="Log", padding="10")
        log_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.log_text = tk.Text(log_frame, height=10, font=('Consolas', 9))
        self.log_text.pack(fill=tk.BOTH, expand=True)
        
        scrollbar = ttk.Scrollbar(log_frame, command=self.log_text.yview)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        # === Bottom buttons ===
        bottom_frame = ttk.Frame(container)
        bottom_frame.pack(fill=tk.X, pady=(10, 0))
        
        ttk.Button(bottom_frame, text="Save Settings", command=self.save_settings).pack(side=tk.LEFT)
        ttk.Button(bottom_frame, text="Minimize to Tray", command=self.minimize_to_tray).pack(side=tk.RIGHT)
        
        # Initial log
        self.log("ErsatzTV Backup Manager started")
        if self.config['ersatztv_data_path']:
            self.log(f"Data folder: {self.config['ersatztv_data_path']}")
    
    def log(self, message):
        """Add message to log"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.log_text.see(tk.END)
        self.root.update()
    
    def browse_exe(self):
        """Browse for ErsatzTV.exe"""
        path = filedialog.askopenfilename(
            title="Select ErsatzTV.exe",
            filetypes=[("Executable", "*.exe"), ("All files", "*.*")]
        )
        if path:
            self.ersatztv_exe_var.set(path)
    
    def browse_data(self):
        """Browse for data folder"""
        path = filedialog.askdirectory(title="Select ErsatzTV Data Folder")
        if path:
            self.ersatztv_data_var.set(path)
    
    def browse_logos(self):
        """Browse for logos folder"""
        path = filedialog.askdirectory(title="Select Channel Logos Folder")
        if path:
            self.logos_path_var.set(path)
    
    def auto_find_data(self):
        """Auto-find ErsatzTV data folder"""
        path = find_ersatztv_data()
        if path:
            self.ersatztv_data_var.set(path)
            self.log(f"Found data folder: {path}")
        else:
            self.log("Could not auto-find ErsatzTV data folder")
            messagebox.showwarning("Not Found", "Could not find ErsatzTV data folder.\nPlease browse manually.")
    
    def save_settings(self):
        """Save all settings"""
        self.config['ersatztv_exe_path'] = self.ersatztv_exe_var.get()
        self.config['ersatztv_data_path'] = self.ersatztv_data_var.get()
        self.config['logos_path'] = self.logos_path_var.get()
        self.config['import_repo_url'] = self.import_repo_var.get()
        self.config['export_repo_url'] = self.export_repo_var.get()
        self.config['auto_export_enabled'] = self.auto_export_enabled_var.get()
        try:
            self.config['auto_export_hours'] = int(self.auto_export_hours_var.get())
        except:
            self.config['auto_export_hours'] = 24
        self.config['auto_backup_on_startup'] = self.auto_backup_startup_var.get()
        self.config['run_on_startup'] = self.run_on_startup_var.get()
        
        save_config(self.config)
        self.log("Settings saved")
    
    def on_startup_toggle(self):
        """Handle run on startup toggle"""
        enable = self.run_on_startup_var.get()
        if set_run_on_startup(enable):
            self.log(f"Run on startup: {'enabled' if enable else 'disabled'}")
        else:
            self.log("Failed to update startup setting")
            self.run_on_startup_var.set(not enable)
    
    def on_auto_export_toggle(self):
        """Handle auto-export toggle"""
        if self.auto_export_enabled_var.get():
            self.start_auto_export_timer()
        else:
            self.stop_auto_export_timer()
    
    def start_auto_export_timer(self):
        """Start the auto-export timer"""
        self.stop_auto_export_timer()
        try:
            hours = int(self.auto_export_hours_var.get())
            ms = hours * 60 * 60 * 1000  # Convert to milliseconds
            self.auto_export_timer = self.root.after(ms, self.auto_export_tick)
            self.log(f"Auto-export scheduled every {hours} hours")
        except:
            pass
    
    def stop_auto_export_timer(self):
        """Stop the auto-export timer"""
        if self.auto_export_timer:
            self.root.after_cancel(self.auto_export_timer)
            self.auto_export_timer = None
    
    def auto_export_tick(self):
        """Called when auto-export timer fires"""
        self.log("Auto-export triggered")
        self.do_export(auto=True)
        self.start_auto_export_timer()  # Reschedule
    
    def do_import(self):
        """Import settings from GitHub"""
        repo_url = self.import_repo_var.get().strip()
        data_path = self.ersatztv_data_var.get().strip()
        
        if not repo_url:
            messagebox.showerror("Error", "Please set the Import GitHub URL")
            return
        if not data_path:
            messagebox.showerror("Error", "Please set the ErsatzTV Data folder")
            return
        
        # Check if ErsatzTV is running
        if is_ersatztv_running():
            if not messagebox.askyesno("Warning", 
                    "ErsatzTV is currently running.\n\n"
                    "It's recommended to close it before importing.\n"
                    "Continue anyway?"):
                return
        
        # Confirm
        if not messagebox.askyesno("Confirm Import",
                f"This will download settings from:\n{repo_url}\n\n"
                f"And replace files in:\n{data_path}\n\n"
                "Continue?"):
            return
        
        self.log(f"Starting import from {repo_url}")
        
        # Run in thread to not block UI
        thread = threading.Thread(target=self._do_import_thread, args=(repo_url, data_path))
        thread.start()
    
    def _do_import_thread(self, repo_url, data_path):
        """Import thread"""
        try:
            # Create temp directory
            temp_dir = Path(os.environ.get('TEMP', '')) / 'ersatztv-backup-import'
            if temp_dir.exists():
                shutil.rmtree(temp_dir)
            temp_dir.mkdir(parents=True)
            
            # Clone repo
            self.log("Cloning repository...")
            success, output = run_git_command(['clone', '--depth', '1', repo_url, str(temp_dir)])
            if not success:
                self.log(f"Git clone failed: {output}")
                return
            
            # Read path mappings from backup metadata
            metadata_file = temp_dir / 'backup_metadata.json'
            old_paths = {}
            if metadata_file.exists():
                with open(metadata_file, 'r') as f:
                    old_paths = json.load(f)
                self.log(f"Found backup from: {old_paths.get('computer_name', 'Unknown')}")
            
            # Scan files in backup
            self.log("Scanning backup contents...")
            
            found_items = []
            missing_items = []
            
            for item in BACKUP_ITEMS:
                src = temp_dir / 'data' / item
                if src.exists():
                    if src.is_dir():
                        file_count = sum(1 for _ in src.rglob('*') if _.is_file())
                        found_items.append(f"  ✓ {item}/ ({file_count} files)")
                    else:
                        size_kb = src.stat().st_size / 1024
                        found_items.append(f"  ✓ {item} ({size_kb:.1f} KB)")
                else:
                    missing_items.append(f"  ✗ {item} (not in backup)")
            
            # Check for logos
            logos_src = temp_dir / 'logos'
            if logos_src.exists():
                logo_count = sum(1 for _ in logos_src.rglob('*') if _.is_file())
                found_items.append(f"  ✓ logos/ ({logo_count} files)")
            
            # Log found items
            self.log(f"\nFound {len(found_items)} items in backup:")
            for item in found_items:
                self.log(item)
            
            if missing_items:
                self.log(f"\nMissing {len(missing_items)} items:")
                for item in missing_items:
                    self.log(item)
            
            self.log("")  # Blank line
            
            # Copy files
            self.log("Copying files...")
            data_path = Path(data_path)
            
            for item in BACKUP_ITEMS:
                src = temp_dir / 'data' / item
                dst = data_path / item
                if src.exists():
                    if src.is_dir():
                        if dst.exists():
                            shutil.rmtree(dst)
                        shutil.copytree(src, dst)
                    else:
                        shutil.copy2(src, dst)
                    self.log(f"  Restored: {item}")
            
            # Copy logos if present
            logos_src = temp_dir / 'logos'
            new_logos_path = self.logos_path_var.get()
            
            if logos_src.exists():
                if not new_logos_path:
                    # Ask user where to put logos
                    self.root.after(0, self._ask_logos_location, logos_src, data_path, old_paths)
                    return
                else:
                    logos_dst = Path(new_logos_path)
                    self.log("Restoring logos...")
                    logos_dst.mkdir(parents=True, exist_ok=True)
                    for item in logos_src.iterdir():
                        dst_item = logos_dst / item.name
                        if item.is_dir():
                            if dst_item.exists():
                                shutil.rmtree(dst_item)
                            shutil.copytree(item, dst_item)
                        else:
                            shutil.copy2(item, dst_item)
                    self.log(f"  Restored logos to: {new_logos_path}")
                    
                    # Update database paths
                    self._update_db_paths(data_path, old_paths, new_logos_path)
            
            # Cleanup
            shutil.rmtree(temp_dir)
            
            self.log("Import complete!")
            self.root.after(0, lambda: messagebox.showinfo("Success", "Import completed successfully!\n\nRestart ErsatzTV to apply changes."))
            
        except Exception as e:
            self.log(f"Import failed: {str(e)}")
            self.root.after(0, lambda: messagebox.showerror("Error", f"Import failed:\n{str(e)}"))
    
    def _ask_logos_location(self, logos_src, data_path, old_paths):
        """Ask user where to restore logos"""
        result = messagebox.askyesno("Logos Found", 
            "The backup contains channel logos.\n\n"
            "Would you like to restore them?\n\n"
            "Click Yes to choose a folder.")
        
        if result:
            new_logos_path = filedialog.askdirectory(title="Choose folder for channel logos")
            if new_logos_path:
                self.logos_path_var.set(new_logos_path)
                # Continue import in thread
                thread = threading.Thread(
                    target=self._finish_logos_import, 
                    args=(logos_src, data_path, old_paths, new_logos_path)
                )
                thread.start()
    
    def _finish_logos_import(self, logos_src, data_path, old_paths, new_logos_path):
        """Finish importing logos after user selects path"""
        try:
            logos_dst = Path(new_logos_path)
            self.log("Restoring logos...")
            logos_dst.mkdir(parents=True, exist_ok=True)
            for item in logos_src.iterdir():
                dst_item = logos_dst / item.name
                if item.is_dir():
                    if dst_item.exists():
                        shutil.rmtree(dst_item)
                    shutil.copytree(item, dst_item)
                else:
                    shutil.copy2(item, dst_item)
            self.log(f"  Restored logos to: {new_logos_path}")
            
            # Update database paths
            self._update_db_paths(data_path, old_paths, new_logos_path)
            
            # Cleanup temp
            temp_dir = logos_src.parent
            shutil.rmtree(temp_dir)
            
            self.log("Import complete!")
            self.root.after(0, lambda: messagebox.showinfo("Success", "Import completed successfully!\n\nRestart ErsatzTV to apply changes."))
        except Exception as e:
            self.log(f"Error finishing import: {e}")
    
    def _update_db_paths(self, data_path, old_paths, new_logos_path):
        """Update paths in the database for the new machine"""
        db_path = data_path / 'ersatztv.sqlite3'
        if not db_path.exists():
            return
        
        self.log("Updating database paths...")
        
        # Get old logos path from metadata
        old_logos_path = old_paths.get('logos_path', '')
        old_data_path = old_paths.get('data_path', '')
        
        if old_logos_path and new_logos_path:
            count = update_logos_path_in_db(str(db_path), old_logos_path, new_logos_path)
            self.log(f"  Updated {count} logo path references")
        
        # Also update data path references if different
        new_data_path = str(data_path)
        if old_data_path and old_data_path != new_data_path:
            count = update_logos_path_in_db(str(db_path), old_data_path, new_data_path)
            self.log(f"  Updated {count} data path references"))
    
    def do_export(self, auto=False):
        """Export settings to GitHub"""
        repo_url = self.export_repo_var.get().strip()
        data_path = self.ersatztv_data_var.get().strip()
        
        if not repo_url:
            if not auto:
                messagebox.showerror("Error", "Please set the Export GitHub URL")
            return
        if not data_path:
            if not auto:
                messagebox.showerror("Error", "Please set the ErsatzTV Data folder")
            return
        
        if not auto:
            if not messagebox.askyesno("Confirm Export",
                    f"This will upload settings from:\n{data_path}\n\n"
                    f"To GitHub:\n{repo_url}\n\n"
                    "Continue?"):
                return
        
        self.log(f"Starting export to {repo_url}")
        
        # Run in thread
        thread = threading.Thread(target=self._do_export_thread, args=(repo_url, data_path, auto))
        thread.start()
    
    def _do_export_thread(self, repo_url, data_path, auto):
        """Export thread"""
        try:
            # Create/use local repo directory
            repo_dir = Path(os.environ.get('LOCALAPPDATA', '')) / 'ErsatzTV-Backup' / 'repo'
            repo_dir.mkdir(parents=True, exist_ok=True)
            
            # Check if repo exists, if not clone
            if not (repo_dir / '.git').exists():
                self.log("Cloning repository...")
                success, output = run_git_command(['clone', repo_url, str(repo_dir)])
                if not success:
                    # Try to init new repo
                    self.log("Initializing new repository...")
                    run_git_command(['init'], cwd=str(repo_dir))
                    run_git_command(['remote', 'add', 'origin', repo_url], cwd=str(repo_dir))
            else:
                # Pull latest
                self.log("Pulling latest...")
                run_git_command(['pull'], cwd=str(repo_dir))
            
            # Create data subdirectory
            backup_data_dir = repo_dir / 'data'
            backup_data_dir.mkdir(exist_ok=True)
            
            # Auto-detect logos path from database
            data_path = Path(data_path)
            db_path = data_path / 'ersatztv.sqlite3'
            detected_logos_path = None
            
            if db_path.exists():
                detected_logos_path = get_logos_path_from_db(str(db_path))
                if detected_logos_path:
                    self.log(f"Detected logos path: {detected_logos_path}")
                    self.logos_path_var.set(detected_logos_path)
            
            # Save metadata about this backup
            metadata = {
                'computer_name': os.environ.get('COMPUTERNAME', 'Unknown'),
                'username': os.environ.get('USERNAME', 'Unknown'),
                'data_path': str(data_path),
                'logos_path': self.logos_path_var.get() or detected_logos_path or '',
                'backup_time': datetime.now().isoformat(),
            }
            
            # Also get all paths from database for reference
            if db_path.exists():
                metadata['database_paths'] = get_all_paths_from_db(str(db_path))
            
            with open(repo_dir / 'backup_metadata.json', 'w') as f:
                json.dump(metadata, f, indent=2)
            self.log("  Saved backup metadata")
            
            # Copy files
            self.log("Scanning for files to backup...")
            
            found_items = []
            missing_items = []
            
            for item in BACKUP_ITEMS:
                src = data_path / item
                if src.exists():
                    if src.is_dir():
                        file_count = sum(1 for _ in src.rglob('*') if _.is_file())
                        found_items.append(f"  ✓ {item}/ ({file_count} files)")
                    else:
                        size_kb = src.stat().st_size / 1024
                        found_items.append(f"  ✓ {item} ({size_kb:.1f} KB)")
                else:
                    missing_items.append(f"  ✗ {item} (not found)")
            
            # Log found items
            self.log(f"\nFound {len(found_items)} of {len(BACKUP_ITEMS)} items:")
            for item in found_items:
                self.log(item)
            
            if missing_items:
                self.log(f"\nMissing {len(missing_items)} items (skipped):")
                for item in missing_items:
                    self.log(item)
            
            self.log("")  # Blank line
            
            # Now copy the files
            self.log("Copying files...")
            
            for item in BACKUP_ITEMS:
                src = data_path / item
                dst = backup_data_dir / item
                if src.exists():
                    if src.is_dir():
                        if dst.exists():
                            shutil.rmtree(dst)
                        shutil.copytree(src, dst)
                    else:
                        shutil.copy2(src, dst)
                    self.log(f"  Backed up: {item}")
            
            # Copy logos if path is set
            logos_path = self.logos_path_var.get() or detected_logos_path
            if logos_path:
                logos_src = Path(logos_path)
                if logos_src.exists():
                    logos_dst = repo_dir / 'logos'
                    self.log("Backing up logos...")
                    if logos_dst.exists():
                        shutil.rmtree(logos_dst)
                    shutil.copytree(logos_src, logos_dst)
                    self.log(f"  Backed up logos from: {logos_path}")
            
            # Git add, commit, push
            self.log("Committing changes...")
            run_git_command(['add', '-A'], cwd=str(repo_dir))
            
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            commit_msg = f"Backup {timestamp}"
            success, output = run_git_command(['commit', '-m', commit_msg], cwd=str(repo_dir))
            
            if 'nothing to commit' in output:
                self.log("No changes to commit")
                return
            
            self.log("Pushing to GitHub...")
            success, output = run_git_command(['push', '-u', 'origin', 'main'], cwd=str(repo_dir))
            if not success:
                # Try master branch
                success, output = run_git_command(['push', '-u', 'origin', 'master'], cwd=str(repo_dir))
            
            if success:
                self.log("Export complete!")
                if not auto:
                    self.root.after(0, lambda: messagebox.showinfo("Success", "Export completed successfully!"))
            else:
                self.log(f"Push failed: {output}")
                if not auto:
                    self.root.after(0, lambda: messagebox.showerror("Error", f"Push failed:\n{output}"))
                    
        except Exception as e:
            self.log(f"Export failed: {str(e)}")
            if not auto:
                self.root.after(0, lambda: messagebox.showerror("Error", f"Export failed:\n{str(e)}"))
    
    def launch_ersatztv(self):
        """Launch ErsatzTV"""
        exe_path = self.ersatztv_exe_var.get().strip()
        if not exe_path:
            messagebox.showerror("Error", "Please set the ErsatzTV.exe path")
            return
        if not Path(exe_path).exists():
            messagebox.showerror("Error", f"ErsatzTV.exe not found at:\n{exe_path}")
            return
        
        try:
            subprocess.Popen([exe_path], cwd=str(Path(exe_path).parent))
            self.log(f"Launched ErsatzTV")
        except Exception as e:
            self.log(f"Failed to launch: {str(e)}")
            messagebox.showerror("Error", f"Failed to launch ErsatzTV:\n{str(e)}")
    
    def minimize_to_tray(self):
        """Minimize to system tray"""
        if HAS_TRAY:
            self.root.withdraw()
            self.create_tray_icon()
        else:
            messagebox.showinfo("Info", 
                "System tray requires pystray and pillow.\n"
                "Install with: pip install pystray pillow\n\n"
                "For now, minimizing to taskbar.")
            self.root.iconify()
    
    def create_tray_icon(self):
        """Create system tray icon"""
        # Create a simple icon
        image = Image.new('RGB', (64, 64), color='#4a9eff')
        draw = ImageDraw.Draw(image)
        draw.rectangle([16, 16, 48, 48], fill='white')
        draw.text((24, 22), "E", fill='#4a9eff')
        
        menu = pystray.Menu(
            pystray.MenuItem("Show", self.show_from_tray),
            pystray.MenuItem("Export Now", lambda: self.do_export()),
            pystray.MenuItem("Launch ErsatzTV", lambda: self.launch_ersatztv()),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Exit", self.exit_app)
        )
        
        self.tray_icon = pystray.Icon(APP_NAME, image, APP_NAME, menu)
        threading.Thread(target=self.tray_icon.run, daemon=True).start()
    
    def show_from_tray(self):
        """Show window from tray"""
        if hasattr(self, 'tray_icon'):
            self.tray_icon.stop()
        self.root.deiconify()
        self.root.lift()
    
    def exit_app(self):
        """Exit the application"""
        if hasattr(self, 'tray_icon'):
            self.tray_icon.stop()
        self.root.quit()
    
    def on_close(self):
        """Handle window close"""
        self.save_settings()
        if HAS_TRAY and messagebox.askyesno("Minimize?", "Minimize to system tray?\n\nClick No to exit completely."):
            self.minimize_to_tray()
        else:
            self.root.quit()


# ═══════════════════════════════════════════════════════════════════════════════
# STARTUP LOGIC
# ═══════════════════════════════════════════════════════════════════════════════

def run_startup_backup():
    """Run backup on startup if configured"""
    config = load_config()
    if config.get('auto_backup_on_startup'):
        print("Running startup backup...")
        # Quick export
        repo_url = config.get('export_repo_url', '')
        data_path = config.get('ersatztv_data_path', '')
        if repo_url and data_path:
            # Simple export logic here
            pass
        
        # Launch ErsatzTV
        exe_path = config.get('ersatztv_exe_path', '')
        if exe_path and Path(exe_path).exists():
            subprocess.Popen([exe_path], cwd=str(Path(exe_path).parent))


def main():
    # Check for startup mode
    if '--startup' in sys.argv:
        run_startup_backup()
        # Still show the app but minimized
    
    root = tk.Tk()
    app = ErsatzTVBackupApp(root)
    root.mainloop()


if __name__ == '__main__':
    main()
